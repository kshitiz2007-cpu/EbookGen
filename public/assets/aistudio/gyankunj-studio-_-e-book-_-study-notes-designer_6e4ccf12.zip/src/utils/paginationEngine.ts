/**
 * Precision Client-Side A4 Pagination Engine
 * Splits content across columns and pages with Keep-With-Next rules,
 * table row splitting, and list item splitting.
 */

import { Block, ChunkedBlockRef, PageLayout } from '../types/ebook';

const PADDING_SAFETY_MARGIN = 4; // px safety to prevent browser rounding overflow

export const distributeBlocksIntoColumns = (
  blocks: Block[],
  blockHeights: number[],
  tableRowHeights: (number[] | null)[],
  tableHeaderHeights: number[],
  maxColumnHeight: number,
  columnsPerPage: number,
  newPageOnH1: boolean
): ChunkedBlockRef[][] => {
  const columns: ChunkedBlockRef[][] = [[]];
  let curHeight = 0;

  const remainingSpace = () => maxColumnHeight - PADDING_SAFETY_MARGIN - curHeight;

  const startNewColumn = () => {
    columns.push([]);
    curHeight = 0;
  };

  const advanceToNewPage = () => {
    while (columns.length % columnsPerPage !== 0) {
      columns.push([]);
    }
    curHeight = 0;
  };

  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    const bHeight = blockHeights[i] || 0;
    const isHeading = block.t === 'h1' || block.t === 'h2' || block.t === 'h3';

    // Estimate next item height for keep-with-next
    const nextItemHeight = isHeading && i + 1 < blocks.length
      ? Math.min(blockHeights[i + 1] || 60, 90)
      : 0;

    // Explicit Page Break
    if (block.t === 'pagebreak') {
      if (columns.some(col => col.length > 0)) {
        advanceToNewPage();
      }
      continue;
    }

    // New Page on H1 option
    if (newPageOnH1 && block.t === 'h1' && columns.some(col => col.length > 0)) {
      advanceToNewPage();
    }

    // Check if entire block fits
    const fits = bHeight <= remainingSpace() && (!isHeading || bHeight + nextItemHeight <= remainingSpace() || curHeight === 0);

    if (fits) {
      columns[columns.length - 1].push({ i });
      curHeight += bHeight;
      continue;
    }

    // Try splitting tables across columns
    const rowHeights = tableRowHeights[i];
    if (rowHeights && rowHeights.length > 0) {
      let rIdx = 0;
      const thHeight = tableHeaderHeights[i] || 32;

      while (rIdx < rowHeights.length) {
        let batchHeight = thHeight;
        let nextR = rIdx;

        while (nextR < rowHeights.length && batchHeight + rowHeights[nextR] <= remainingSpace()) {
          batchHeight += rowHeights[nextR];
          nextR++;
        }

        // Avoid leaving single orphan rows if not at start
        const isTooSmall = (nextR - rIdx) < Math.min(2, rowHeights.length - rIdx) && curHeight > 0;
        if (nextR === rIdx || isTooSmall) {
          if (curHeight === 0 && nextR === rIdx) {
            nextR = rIdx + 1; // force at least 1 row if empty column
          } else {
            startNewColumn();
            continue;
          }
        }

        const isFullTable = rIdx === 0 && nextR === rowHeights.length;
        columns[columns.length - 1].push(
          isFullTable ? { i } : { i, r0: rIdx, r1: nextR }
        );
        curHeight += batchHeight;
        rIdx = nextR;

        if (rIdx < rowHeights.length) {
          startNewColumn();
        }
      }
      continue;
    }

    // Block didn't fit and couldn't be split: move to next column
    if (curHeight > 0) {
      startNewColumn();
    }
    columns[columns.length - 1].push({ i });
    curHeight += bHeight;
  }

  // Remove trailing completely empty columns except the first
  while (columns.length > 1 && columns[columns.length - 1].length === 0) {
    columns.pop();
  }

  return columns;
};

export const assemblePages = (
  columns: ChunkedBlockRef[][],
  blocks: Block[],
  columnsPerPage: number
): PageLayout[] => {
  const pages: PageLayout[] = [];

  for (let i = 0; i < columns.length; i += columnsPerPage) {
    const pageCols = columns.slice(i, i + columnsPerPage);

    // Pad if last page has fewer columns than layout
    while (pageCols.length < columnsPerPage) {
      pageCols.push([]);
    }

    // Identify active chapter/section heading
    let activeSection = '';
    for (let c = 0; c < pageCols.length; c++) {
      for (const item of pageCols[c]) {
        const b = blocks[item.i];
        if (b && b.t === 'h1') {
          activeSection = b.text;
        }
      }
    }

    // Fallback to previous page's section or document's first h1
    if (!activeSection && pages.length > 0) {
      activeSection = pages[pages.length - 1].section;
    }
    if (!activeSection) {
      const firstH1 = blocks.find(b => b.t === 'h1');
      activeSection = firstH1 && firstH1.t === 'h1' ? firstH1.text : '';
    }

    pages.push({
      columns: pageCols,
      section: activeSection,
    });
  }

  if (pages.length === 0) {
    pages.push({ columns: [[]], section: '' });
  }

  return pages;
};
