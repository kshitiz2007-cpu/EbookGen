/**
 * Hindi & Bilingual Text Formatting Utilities
 */

export const cleanHindiTypography = (text: string): string => {
  let res = text;
  // Replace standalone vertical bars used at sentence end with Devanagari Danda
  res = res.replace(/(\S)\s*\|\s*$/gm, '$1।');
  res = res.replace(/(\S)\s*\|\s+(\S)/g, '$1। $2');
  // Double vertical bars to double danda
  res = res.replace(/\|\|/g, '॥');
  // Normalize multiple spaces
  res = res.replace(/[ \t]{2,}/g, ' ');
  // Normalize quotes
  res = res.replace(/[""]/g, '"').replace(/['']/g, "'");
  return res;
};

export const calculateReadingTime = (wordCount: number): string => {
  const wpm = 180; // Standard Hindi/English study reading speed
  const mins = Math.ceil(wordCount / wpm);
  if (mins <= 1) return 'लगभग 1 मिनट पठन';
  return `लगभग ${mins} मिनट पठन`;
};

export const SNIPPETS = {
  h1: '\n# नया अध्याय शीर्षक (H1)\n',
  h2: '\n## महत्वपूर्ण उप-शीर्षक (H2)\n',
  h3: '\n### मुख्य बिंदु (H3)\n',
  fact: '\n> तथ्य: यहाँ महत्वपूर्ण तथ्य या आँकड़ा लिखें।\n',
  note: '\n> नोट: यहाँ विशेष टिप्पणी अथवा अपवाद लिखें।\n',
  tip: '\n> याद रखें: परीक्षा में सीधे पूछे जाने वाले सूत्र या संकेत।\n',
  warning: '\n> चेतावनी: सामान्यतः होने वाली गलतियाँ और सावधानियाँ।\n',
  quote: '\n> "यहाँ कोई प्रेरक अथवा संवैधानिक उद्धरण लिखें।"\n',
  table: `
| क्रम | विषय / प्रावधान | अनुच्छेद / वर्ष |
|---|---|---|
| 1 | मौलिक अधिकार | अनुच्छेद 12-35 |
| 2 | नीति निदेशक तत्व | अनुच्छेद 36-51 |
| 3 | मौलिक कर्तव्य | अनुच्छेद 51A |
`,
  mcq: `
[MCQ]
Q: संविधान के किस भाग में संघ राज्य क्षेत्रों का उल्लेख है?
(A) भाग VI
(B) भाग VII
(C) भाग VIII
(D) भाग IX
Ans: C
Exp: संविधान के भाग VIII (अनुच्छेद 239-241) में संघ राज्य क्षेत्रों के प्रशासन के संबंध में विशेष उपबंध हैं।
[/MCQ]
`,
  qrcode: '\n[QR: https://example.com/lecture | वीडियो लेक्चर देखें]\n',
  signature: '\n[SIGN: डॉ. ज्ञान प्रकाश | विभागाध्यक्ष (सिविल सेवा प्रकोष्ठ)]\n',
  pagebreak: '\n===\n',
};
