/**
 * Advanced Markdown & Educational Content Parser
 * Supports headings, bilingual study callouts, tables, lists, MCQs, QR codes, and page breaks.
 */

import { Block } from '../types/ebook';

export interface ParsedDocument {
  meta: Record<string, string>;
  body: string;
}

export const extractFrontmatter = (raw: string): ParsedDocument => {
  const normalized = raw.replace(/\r/g, '').replace(/^\uFEFF/, '');
  const match = normalized.match(/^---[ \t]*\n([\s\S]*?)\n---[ \t]*(?:\n|$)/);
  if (!match) {
    return { meta: {}, body: normalized };
  }
  const meta: Record<string, string> = {};
  for (const line of match[1].split('\n')) {
    const kv = line.match(/^\s*([A-Za-z0-9_-]+)\s*:\s*(.*?)\s*$/);
    if (kv) {
      meta[kv[1].toLowerCase()] = kv[2];
    }
  }
  return { meta, body: normalized.slice(match[0].length) };
};

const splitTableRow = (row: string): string[] => {
  return row
    .trim()
    .replace(/^\|/, '')
    .replace(/\|$/, '')
    .split('|')
    .map(cell => cell.trim());
};

export const parseMarkdownToBlocks = (source: string): Block[] => {
  const { body } = extractFrontmatter(source);
  const lines = body.split('\n');
  const blocks: Block[] = [];
  let buffer: string[] = [];

  const flushParagraph = () => {
    if (buffer.length > 0) {
      blocks.push({ t: 'p', text: buffer.join(' ') });
      buffer = [];
    }
  };

  let idx = 0;
  while (idx < lines.length) {
    const rawLine = lines[idx];
    const trimmed = rawLine.trim();

    if (!trimmed) {
      flushParagraph();
      idx++;
      continue;
    }

    // Comment line
    if (trimmed.startsWith('%%')) {
      idx++;
      continue;
    }

    // Page break
    if (/^(={3,}|-{3}\s*pagebreak\s*-{3})$/i.test(trimmed)) {
      flushParagraph();
      blocks.push({ t: 'pagebreak' });
      idx++;
      continue;
    }

    // MCQ Block parser
    if (/^\[mcq\]/i.test(trimmed)) {
      flushParagraph();
      idx++;
      let question = '';
      const options: { key: string; text: string }[] = [];
      let answer = '';
      let explanation = '';

      while (idx < lines.length && !/^\[\/mcq\]/i.test(lines[idx].trim())) {
        const mcqLine = lines[idx].trim();
        const qMatch = mcqLine.match(/^(?:Q|प्रश्न)\s*[:.]\s*(.*)$/i);
        const optMatch = mcqLine.match(/^\(([A-Da-d1-4])\)\s*(.*)$/);
        const ansMatch = mcqLine.match(/^(?:Ans|उत्तर)\s*[:.]\s*([A-Da-d1-4])/i);
        const expMatch = mcqLine.match(/^(?:Exp|व्याख्या|Explanation)\s*[:.]\s*(.*)$/i);

        if (qMatch) {
          question = qMatch[1];
        } else if (optMatch) {
          options.push({ key: optMatch[1].toUpperCase(), text: optMatch[2] });
        } else if (ansMatch) {
          answer = ansMatch[1].toUpperCase();
        } else if (expMatch) {
          explanation = expMatch[1];
        } else if (!question) {
          question = mcqLine;
        } else if (explanation) {
          explanation += ' ' + mcqLine;
        }
        idx++;
      }
      if (idx < lines.length && /^\[\/mcq\]/i.test(lines[idx].trim())) {
        idx++;
      }
      if (question) {
        blocks.push({
          t: 'mcq',
          question,
          options,
          answer: answer || undefined,
          explanation: explanation || undefined,
        });
      }
      continue;
    }

    // QR Code block
    const qrMatch = trimmed.match(/^\[(?:qr|qrcode)\s*:\s*([^|\]]+)(?:\|\s*([^\]]+))?\]/i);
    if (qrMatch) {
      flushParagraph();
      blocks.push({
        t: 'qrcode',
        url: qrMatch[1].trim(),
        label: (qrMatch[2] || 'स्कैन करें').trim(),
      });
      idx++;
      continue;
    }

    // Signature block
    const signMatch = trimmed.match(/^\[(?:sign|signature)\s*:\s*([^|\]]+)(?:\|\s*([^\]]+))?\]/i);
    if (signMatch) {
      flushParagraph();
      blocks.push({
        t: 'signature',
        name: signMatch[1].trim(),
        title: (signMatch[2] || 'प्रमाणित').trim(),
      });
      idx++;
      continue;
    }

    // Headings H1, H2, H3
    const headMatch = trimmed.match(/^(#{1,3})\s+(.*)$/);
    if (headMatch) {
      flushParagraph();
      const level = headMatch[1].length;
      blocks.push({
        t: ('h' + level) as 'h1' | 'h2' | 'h3',
        text: headMatch[2].trim(),
      });
      idx++;
      continue;
    }

    // Unordered lists
    if (/^[-*•]\s+/.test(trimmed)) {
      flushParagraph();
      const items: string[] = [];
      while (idx < lines.length && /^[-*•]\s+/.test(lines[idx].trim())) {
        items.push(lines[idx].trim().replace(/^[-*•]\s+/, ''));
        idx++;
      }
      blocks.push({ t: 'ul', items });
      continue;
    }

    // Numbered lists
    if (/^\d+[.)]\s+/.test(trimmed)) {
      flushParagraph();
      const items: string[] = [];
      while (idx < lines.length && /^\d+[.)]\s+/.test(lines[idx].trim())) {
        items.push(lines[idx].trim().replace(/^\d+[.)]\s+/, ''));
        idx++;
      }
      blocks.push({ t: 'ol', items });
      continue;
    }

    // Callout boxes
    if (trimmed.startsWith('>')) {
      flushParagraph();
      const calloutText = trimmed.replace(/^>\s*/, '');
      const calloutMatch = calloutText.match(/^(तथ्य|Fact|नोट|Note|याद रखें|Tip|महत्वपूर्ण|चेतावनी|Warning)\s*[:：]\s*(.*)$/i);

      if (calloutMatch) {
        const tag = calloutMatch[1];
        let kind: 'fact' | 'note' | 'tip' | 'warning' = 'note';
        if (/तथ्य|fact/i.test(tag)) kind = 'fact';
        else if (/याद|tip/i.test(tag)) kind = 'tip';
        else if (/चेतावनी|warning/i.test(tag)) kind = 'warning';
        blocks.push({
          t: 'callout',
          kind,
          label: tag,
          text: calloutMatch[2].trim(),
        });
      } else {
        blocks.push({
          t: 'callout',
          kind: 'quote',
          text: calloutText.trim(),
        });
      }
      idx++;
      continue;
    }

    // Markdown tables
    if (trimmed.startsWith('|')) {
      flushParagraph();
      const tableRows: string[][] = [];
      while (idx < lines.length && lines[idx].trim().startsWith('|')) {
        const curRow = lines[idx].trim();
        // Skip separator row |---|---|
        if (!/^\s*\|?[\s:|-]+\|?\s*$/.test(curRow) || !curRow.includes('-')) {
          tableRows.push(splitTableRow(curRow));
        }
        idx++;
      }
      if (tableRows.length > 0) {
        blocks.push({
          t: 'table',
          head: tableRows[0] || [],
          rows: tableRows.slice(1),
        });
      }
      continue;
    }

    // Standard paragraph line
    buffer.push(trimmed);
    idx++;
  }

  flushParagraph();
  return blocks;
};

export const countWords = (text: string): number => {
  const { body } = extractFrontmatter(text);
  const cleaned = body.replace(/^%%.*$/gm, '').trim();
  const tokens = cleaned.match(/[\p{L}\p{M}\p{N}]+/gu);
  return tokens ? tokens.length : 0;
};
